
export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gray-100 text-center">
      <div>
        <h1 className="text-4xl font-bold text-gray-800">Welcome to QCCC Ltd</h1>
        <p className="mt-4 text-lg text-gray-600">Your trusted partner for concrete cutting and coring.</p>
      </div>
    </main>
  );
}
